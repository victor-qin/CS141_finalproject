gcc -o cs141_final main.c
